package com.bayuwp.skorplay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;

import static java.lang.String.*;

public class Main2Activity extends AppCompatActivity {

    @BindView(R.id.tv_nameteamA) TextView namaTeamA;
    @BindView(R.id.tv_nameteamB) TextView namaTeamB;
    @BindView(R.id.tv_skorteamA) TextView skorTeamA;
    @BindView(R.id.tv_skorteamB) TextView skorTeamB;
    @BindView(R.id.btn_teamA_tambah) TextView btnTeamATambah;
    @BindView(R.id.btn_teamA_kurang) TextView btnTeamAKurang;
    @BindView(R.id.btn_teamB_tambah) TextView btnTeamBTambah;
    @BindView(R.id.btn_teamB_kurang) TextView btnTeamBKurang;
    @BindView(R.id.btn_cekhasil) TextView btnCekHasil;
    @BindView(R.id.btn_reset) TextView btnReset;

    String getteamA, getteamB;
    int skorA = 0;
    int skorB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ButterKnife.bind(this);

        getteamA = getIntent().getExtras().get("TeamA").toString();
        getteamB = getIntent().getExtras().get("TeamB").toString();

        namaTeamA.setText(getteamA);
        namaTeamB.setText(getteamB);

        //Klik Tombol Tambah Team A//
        btnTeamATambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                skorA = skorA+1;
                skorTeamA.setText(valueOf(skorA));
            }
        });
        //Klik Tombol Tambah Team B//
        btnTeamBTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                skorB = skorB+1;
                skorTeamB.setText(valueOf(skorB));
            }
        });
        //Klik Tombol Kurang Team A//
        btnTeamAKurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                skorA = skorA-1;
                skorTeamA.setText(valueOf(skorA));
            }
        });
        //Klik Tombol Kurang Team A//
        btnTeamBKurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                skorB = skorB-1;
                skorTeamB.setText(valueOf(skorB));
            }
        });

        //Click Tombol Cek Hasil//
        btnCekHasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hasilA = Integer.parseInt(skorTeamA.getText().toString());
                int hasilB = Integer.parseInt(skorTeamB.getText().toString());
                if (hasilA > hasilB){
                    Toast.makeText(Main2Activity.this, "Team "+namaTeamA+" Memenangkan Pertandingan ",Toast.LENGTH_SHORT).show();
                }
                else if (hasilA < hasilB) {
                    Toast.makeText(Main2Activity.this, "Team "+namaTeamA+" Memenangkan Pertandingan ",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(Main2Activity.this, "Pertandingan Ini Seri",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                skorTeamA.setText("0");
                skorTeamB.setText("0");
            }
        });
    }

}
